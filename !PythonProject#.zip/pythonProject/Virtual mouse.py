{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "ff5a8bbd",
   "metadata": {},
   "outputs": [],
   "source": [
    "import mediapipe\n",
    "import cv2\n",
    "import numpy\n",
    "import autopy\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "0fe8b4a3",
   "metadata": {},
   "outputs": [],
   "source": [
    "initHand=mediapipe.solutions.hands\n",
    "#Object of mediapipe with arguments for the hand module\n",
    "mainHand=initHand.Hands(min_detection_confidence=0.8, min_tracking_confidence=0.8)\n",
    "draw=mediapipe.solutions.drawing_utils  #Object to draw the coonections between each finger index\n",
    "wScr,hScr=autopy.screen.size()      #Height and width of the screen i.e 1920* 1080\n",
    "pX,pY=0,0   #Previous locations of x and y \n",
    "cX,cY=0,0     #Current locations of x and y "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "35ee9964",
   "metadata": {},
   "outputs": [],
   "source": [
    "cap=cv2.VideoCapture(0)\n",
    "\n",
    "def handLandmarks(colorImg):\n",
    "    landmarkList=[]    #Default values if no landmarks are tracked\n",
    "    landmarkPositions=mainHand.process(colorImg)      #Object for processing the video input\n",
    "    landmarkCheck=landmarkPositions.multi_hand_landmarks   #Stores the out out of the processing image\n",
    "    if landmarkCheck:             #Check if landmarks are tracked\n",
    "        for hand in landmarkCheck:      #Lanfmarks for each finger\n",
    "            for index,landmark in enumerate(hand.landmark): #Loops through the 21 indexes and outputs their landamrks coordinated:x,y and z:\n",
    "                draw.draw_landmarks(img,hand,initHand.HAND_CONNECTIONS)   #drawing each index on the hand with connections\n",
    "                h,w,c=img.shape      #Height , width and channel on the image\n",
    "                centreX, centreY=int(landmark.x*w),int(landmark.y*h)\n",
    "                landmarkList.append([index,centreX,centreY])#Adding index to each coordinate\n",
    "    return landmarkList\n",
    "\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "3bac735e",
   "metadata": {},
   "outputs": [],
   "source": [
    "def fingers(landmarks):\n",
    "    fingerTips=[]   #To store 4 sets of 1s and 0s\n",
    "    tipIds=[4,8,12,16,20]  #Indexes of the  tips of finger\n",
    "    # Checking if thumb is up\n",
    "    if landmarks[tipIds[0]][1]> lmList[tipIds[0]-1][1]:\n",
    "        fingerTips.append(1)\n",
    "    else:\n",
    "        fingerTips.append(0)\n",
    "    \n",
    "    #Checking if fingers are up(except the thumb)\n",
    "    for id in range(1,5):\n",
    "        if landmarks[tipIds[id]][2]< lmList[tipIds[id]-3][2]: #checks if finger is higher than the joint\n",
    "            fingerTips.append(1)\n",
    "        else:\n",
    "            fingerTips.append(0)\n",
    "    return fingerTips\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "7d59ab52",
   "metadata": {},
   "outputs": [],
   "source": [
    "while (cap.isOpened()):\n",
    "    ckeck,img=cap.read()    #Read frames from the camera\n",
    "    imgRGB=cv2.cvtColor(img,cv2.COLOR_BGR2RGB)\n",
    "    lmList=handLandmarks(imgRGB)\n",
    "    \n",
    "    if len(lmList) !=0:\n",
    "        x1,y1=lmList[8][1:]    #Gets index 8s x and y values \n",
    "        x2,y2=lmList[12][1:]    #Gets index 12s x and y values\n",
    "        finger = fingers(lmList)\n",
    "        \n",
    "        if finger[1]==1 and finger[2]==0:\n",
    "            x3=numpy.interp(x1,(75,640-75),(0,wScr))   #COnverts the width of the window relative to the screen width\n",
    "            y3=numpy.interp(y1,(75,480-75),(0,hScr))   #COnverts the height of the window relative to the screen height\\\n",
    "            \n",
    "            cX=pX+(x3-pX)/7   #Stores previous x locations to update current x location\n",
    "            cY=pY+(y3-pY)/7   #Stores previous y locations to update current y location\n",
    "            \n",
    "            autopy.mouse.move(wScr-cX,cY)\n",
    "            pX,pY=cX,cY  # Stores the current x and y locations as previous x and y location\n",
    "            \n",
    "        if finger[1]==0 and finger[0]==1:   # pointer finger is down and thumb is up\n",
    "            autopy.mouse.click()   #left click\n",
    "            \n",
    "        \n",
    "    cv2.imshow(\"Frame\",img)\n",
    "    if cv2.waitKey(1) &  0xFF ==ord ('q'):\n",
    "        break\n",
    "            \n"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.8.8"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
